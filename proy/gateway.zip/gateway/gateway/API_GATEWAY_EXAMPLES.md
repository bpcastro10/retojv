# Ejemplos de Uso del API Gateway

## Configuración de Puertos

- **Gateway**: `http://localhost:8082`
- **Microservicio Clientes**: `http://localhost:8080`
- **Microservicio Cuentas**: `http://localhost:8081`

## Ejemplos de Peticiones

### 1. Microservicio de Clientes

#### Obtener todos los clientes
```bash
# Antes (directo al microservicio)
GET http://localhost:8080/v1/clientes

# Ahora (a través del Gateway)
GET http://localhost:8082/api/v1/clientes
```

#### Obtener cliente por ID
```bash
# Antes
GET http://localhost:8080/v1/clientes/123

# Ahora
GET http://localhost:8082/api/v1/clientes/123
```

#### Crear nuevo cliente
```bash
# Antes
POST http://localhost:8080/v1/clientes
Content-Type: application/json

{
  "nombre": "Juan Pérez",
  "email": "juan@example.com"
}

# Ahora
POST http://localhost:8082/api/v1/clientes
Content-Type: application/json

{
  "nombre": "Juan Pérez",
  "email": "juan@example.com"
}
```

### 2. Microservicio de Cuentas

#### Obtener todas las cuentas
```bash
# Antes
GET http://localhost:8081/v1/cuentas

# Ahora
GET http://localhost:8082/api/v1/cuentas
```

#### Obtener cuenta por ID
```bash
# Antes
GET http://localhost:8081/v1/cuentas/456

# Ahora
GET http://localhost:8082/api/v1/cuentas/456
```

#### Crear nueva cuenta
```bash
# Antes
POST http://localhost:8081/v1/cuentas
Content-Type: application/json

{
  "numeroCuenta": "1234567890",
  "saldo": 1000.00,
  "clienteId": 123
}

# Ahora
POST http://localhost:8082/api/v1/cuentas
Content-Type: application/json

{
  "numeroCuenta": "1234567890",
  "saldo": 1000.00,
  "clienteId": 123
}
```

### 3. Microservicio de Movimientos

#### Obtener todos los movimientos
```bash
# Antes
GET http://localhost:8081/v1/movimientos

# Ahora
GET http://localhost:8082/api/v1/movimientos
```

#### Crear nuevo movimiento
```bash
# Antes
POST http://localhost:8081/v1/movimientos
Content-Type: application/json

{
  "cuentaId": 456,
  "tipo": "DEPOSITO",
  "monto": 500.00,
  "descripcion": "Depósito inicial"
}

# Ahora
POST http://localhost:8082/api/v1/movimientos
Content-Type: application/json

{
  "cuentaId": 456,
  "tipo": "DEPOSITO",
  "monto": 500.00,
  "descripcion": "Depósito inicial"
}
```

### 4. Microservicio de Reportes

#### Generar reporte de estado de cuenta
```bash
# Antes
GET http://localhost:8081/v1/reportes/estado-cuenta/456

# Ahora
GET http://localhost:8082/api/v1/reportes/estado-cuenta/456
```

## Endpoints del Gateway

### Verificar salud del Gateway
```bash
GET http://localhost:8082/health
```

Respuesta esperada:
```json
{
  "status": "UP",
  "service": "API Gateway",
  "timestamp": 1640995200000,
  "version": "1.0.0",
  "microservices": {
    "clientes": "http://localhost:8080",
    "cuentas": "http://localhost:8081"
  }
}
```

### Ver rutas configuradas
```bash
GET http://localhost:8082/actuator/gateway/routes
```

### Ver estado de salud detallado
```bash
GET http://localhost:8082/actuator/health
```

## Manejo de Errores

### Cuando un microservicio no está disponible

Si el microservicio de clientes no está disponible, el Gateway responderá con:

```bash
GET http://localhost:8082/api/v1/clientes
```

Respuesta:
```json
{
  "mensaje": "El servicio de clientes no está disponible en este momento",
  "codigo": "SERVICE_UNAVAILABLE",
  "timestamp": 1640995200000
}
```

## Ventajas del Gateway

1. **Punto único de entrada**: Todas las peticiones pasan por un solo punto
2. **Circuit Breaker**: Manejo automático de fallos
3. **CORS centralizado**: Configuración única para todos los servicios
4. **Logging centralizado**: Todas las peticiones se registran en un lugar
5. **Monitoreo**: Endpoints de Actuator para monitoreo
6. **Fallbacks**: Respuestas de error cuando los servicios no están disponibles

## Testing con cURL

### Ejemplo de petición GET
```bash
curl -X GET http://localhost:8082/api/v1/clientes
```

### Ejemplo de petición POST
```bash
curl -X POST http://localhost:8082/api/v1/clientes \
  -H "Content-Type: application/json" \
  -d '{"nombre": "Juan Pérez", "email": "juan@example.com"}'
```

### Ejemplo de petición PUT
```bash
curl -X PUT http://localhost:8082/api/v1/clientes/123 \
  -H "Content-Type: application/json" \
  -d '{"nombre": "Juan Pérez Actualizado", "email": "juan.nuevo@example.com"}'
```

### Ejemplo de petición DELETE
```bash
curl -X DELETE http://localhost:8082/api/v1/clientes/123
``` 