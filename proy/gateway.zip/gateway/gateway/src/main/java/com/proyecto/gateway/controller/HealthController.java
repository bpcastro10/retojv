package com.proyecto.gateway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/health")
public class HealthController {

    @GetMapping
    public ResponseEntity<Map<String, Object>> health() {
        Map<String, Object> response = new HashMap<>();
        response.put("status", "UP");
        response.put("service", "API Gateway");
        response.put("timestamp", System.currentTimeMillis());
        response.put("version", "1.0.0");
        
        Map<String, String> services = new HashMap<>();
        services.put("clientes", "http://localhost:8080");
        services.put("cuentas", "http://localhost:8081");
        
        response.put("microservices", services);
        
        return ResponseEntity.ok(response);
    }
} 