package com.proyecto.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                // Rutas para microservicio de clientes
                .route("clientes_route", r -> r
                        .path("/api/v1/clientes/**")
                        .filters(f -> f
                                .rewritePath("/api/v1/clientes/(?<segment>.*)", "/v1/clientes/${segment}")
                                .circuitBreaker(config -> config
                                        .setName("clientesCircuitBreaker")
                                        .setFallbackUri("forward:/fallback/clientes"))
                        )
                        .uri("http://localhost:8080"))
                
                // Rutas para microservicio de cuentas
                .route("cuentas_route", r -> r
                        .path("/api/v1/cuentas/**")
                        .filters(f -> f
                                .rewritePath("/api/v1/cuentas/(?<segment>.*)", "/v1/cuentas/${segment}")
                                .circuitBreaker(config -> config
                                        .setName("cuentasCircuitBreaker")
                                        .setFallbackUri("forward:/fallback/cuentas"))
                        )
                        .uri("http://localhost:8081"))
                
                // Rutas para movimientos
                .route("movimientos_route", r -> r
                        .path("/api/v1/movimientos/**")
                        .filters(f -> f
                                .rewritePath("/api/v1/movimientos/(?<segment>.*)", "/v1/movimientos/${segment}")
                                .circuitBreaker(config -> config
                                        .setName("movimientosCircuitBreaker")
                                        .setFallbackUri("forward:/fallback/movimientos"))
                        )
                        .uri("http://localhost:8081"))
                
                // Rutas para reportes
                .route("reportes_route", r -> r
                        .path("/api/v1/reportes/**")
                        .filters(f -> f
                                .rewritePath("/api/v1/reportes/(?<segment>.*)", "/v1/reportes/${segment}")
                                .circuitBreaker(config -> config
                                        .setName("reportesCircuitBreaker")
                                        .setFallbackUri("forward:/fallback/reportes"))
                        )
                        .uri("http://localhost:8081"))
                
                .build();
    }
} 