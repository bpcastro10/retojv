package com.proyecto.gateway.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/fallback")
public class FallbackController {

    @GetMapping("/clientes")
    public ResponseEntity<Map<String, Object>> clientesFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("mensaje", "El servicio de clientes no está disponible en este momento");
        response.put("codigo", "SERVICE_UNAVAILABLE");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }

    @GetMapping("/cuentas")
    public ResponseEntity<Map<String, Object>> cuentasFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("mensaje", "El servicio de cuentas no está disponible en este momento");
        response.put("codigo", "SERVICE_UNAVAILABLE");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }

    @GetMapping("/movimientos")
    public ResponseEntity<Map<String, Object>> movimientosFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("mensaje", "El servicio de movimientos no está disponible en este momento");
        response.put("codigo", "SERVICE_UNAVAILABLE");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }

    @GetMapping("/reportes")
    public ResponseEntity<Map<String, Object>> reportesFallback() {
        Map<String, Object> response = new HashMap<>();
        response.put("mensaje", "El servicio de reportes no está disponible en este momento");
        response.put("codigo", "SERVICE_UNAVAILABLE");
        response.put("timestamp", System.currentTimeMillis());
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(response);
    }
} 