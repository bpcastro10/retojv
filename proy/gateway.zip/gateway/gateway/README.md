# API Gateway

Este es el API Gateway que centraliza el acceso a todos los microservicios del proyecto.

## Configuración

### Puerto
El Gateway se ejecuta en el puerto **8082**

### Microservicios Configurados

1. **Microservicio de Clientes** (Puerto 8080)
   - Rutas: `/api/v1/clientes/**`
   - Redirige a: `http://localhost:8080/v1/clientes/**`

2. **Microservicio de Cuentas** (Puerto 8081)
   - Rutas: `/api/v1/cuentas/**`
   - Redirige a: `http://localhost:8081/v1/cuentas/**`

3. **Microservicio de Movimientos** (Puerto 8081)
   - Rutas: `/api/v1/movimientos/**`
   - Redirige a: `http://localhost:8081/v1/movimientos/**`

4. **Microservicio de Reportes** (Puerto 8081)
   - Rutas: `/api/v1/reportes/**`
   - Redirige a: `http://localhost:8081/v1/reportes/**`

## Endpoints del Gateway

### Salud del Gateway
- `GET /health` - Estado del Gateway y microservicios

### Fallbacks
- `GET /fallback/clientes` - Respuesta cuando el servicio de clientes no está disponible
- `GET /fallback/cuentas` - Respuesta cuando el servicio de cuentas no está disponible
- `GET /fallback/movimientos` - Respuesta cuando el servicio de movimientos no está disponible
- `GET /fallback/reportes` - Respuesta cuando el servicio de reportes no está disponible

### Actuator
- `GET /actuator/health` - Estado de salud detallado
- `GET /actuator/gateway/routes` - Rutas configuradas

## Ejemplos de Uso

### Acceder a clientes a través del Gateway
```bash
# En lugar de: http://localhost:8080/v1/clientes
# Usar: http://localhost:8082/api/v1/clientes
```

### Acceder a cuentas a través del Gateway
```bash
# En lugar de: http://localhost:8081/v1/cuentas
# Usar: http://localhost:8082/api/v1/cuentas
```

### Acceder a movimientos a través del Gateway
```bash
# En lugar de: http://localhost:8081/v1/movimientos
# Usar: http://localhost:8082/api/v1/movimientos
```

## Características

- **Circuit Breaker**: Manejo automático de fallos con Resilience4j
- **CORS**: Configuración global de CORS
- **Logging**: Logging detallado de todas las peticiones
- **Fallbacks**: Respuestas de error cuando los servicios no están disponibles
- **Monitoreo**: Endpoints de Actuator para monitoreo

## Ejecución

```bash
cd proy-main/proy/gateway/gateway
./mvnw spring-boot:run
```

## Dependencias

- Spring Cloud Gateway
- Spring Boot Actuator
- Resilience4j Circuit Breaker
- Lombok 